<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $word = $_POST['word'] ?? '';
    if (!empty($word)) {
        echo password_hash($word, PASSWORD_DEFAULT);
        exit;
    }
}
?>

<form method="POST">
    <input type="text" name="word" placeholder="Enter text" required>
    <button type="submit">Hash</button>
</form>
