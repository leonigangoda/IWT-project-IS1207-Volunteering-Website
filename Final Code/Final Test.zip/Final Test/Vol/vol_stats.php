<?php
if (!isset($_SESSION['volunteer_id'])) {
    die("Access denied!");
}

$volunteer_id = (int)$_SESSION['volunteer_id'];

// Number of events the logged-in volunteer has enrolled in
$enrolledQuery = "SELECT COUNT(*) AS total FROM event_assignment WHERE volunteer_id = $volunteer_id";
$enrolledResult = $conn->query($enrolledQuery);
$enrolledEvents = $enrolledResult->fetch_assoc()['total'] ?? 0;

// Total available events
$availableQuery = "SELECT COUNT(*) AS total FROM Event";
$availableResult = $conn->query($availableQuery);
$totalEvents = $availableResult->fetch_assoc()['total'] ?? 0;
?>

<div class="stats-container">
    <div class="stat-card">
        <div class="stat-label">Enrolled Events</div>
        <div class="stat-number"><?php echo $enrolledEvents; ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-label">Total Available Events</div>
        <div class="stat-number"><?php echo $totalEvents; ?></div>
    </div>
</div>
