<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");


if (!isset($_SESSION['volunteer_id'])) {
    $_SESSION['volunteer_id'] = 1; 
}

$vol_id = $_SESSION['volunteer_id'];

// Volunteer details
$query = "SELECT * FROM volunteer WHERE volunteer_id='$vol_id'";
$result = $conn->query($query);
$volunteer = $result->fetch_assoc();

// Available events 
$available_sql = "
    SELECT e.event_id, e.event_name, e.event_venue, e.event_time, e.description, e.category, o.org_name
    FROM event e
    JOIN organization o ON e.org_id = o.org_id
    WHERE e.event_id NOT IN (
        SELECT event_id FROM event_assignment WHERE volunteer_id='$vol_id'
    )";
$available_events = $conn->query($available_sql);

// enrolled events 
$enrolled_sql = "SELECT E.event_id, E.event_name, O.org_name, A.activity_status
                 FROM event_assignment AS A
                 JOIN Event AS E ON A.event_id = E.event_id
                 JOIN Organization AS O ON E.org_id = O.org_id
                 WHERE A.volunteer_id = '$vol_id'";

$enrolled_events = $conn->query($enrolled_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Functionalities Page</title>
    <link rel="stylesheet" href="styless.css">

</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="../Landing Page/landingpage.html"><img src="../Landing Page/logo.png" alt="Vollie logo"></a>
        </div>
        <div class="btns">
            <button type="button" class="login-btn" onclick="location.href='myd_vol.php'">My Dashboard</button>
            <button type="button" class="login-btn" onclick="location.href='#'">Explore Events</button>
            <button type="button" class="login-btn" onclick="location.href='../Login & Reg/logout.php'">Logout</button>
        </div>
    </nav>
    <section class="dashboard">
        <div class="available-events">
            <h2>Available Events</h2>
            <div class="event-list">
                <?php
                if ($available_events->num_rows > 0) {
                    while($row = $available_events->fetch_assoc()) {
                ?>
                <div class="event-card">
                    <h3><?php echo htmlspecialchars($row['event_name']); ?></h3>
                    <p><b>Organization:</b> <?php echo htmlspecialchars($row['org_name']); ?></p>
                    <p><b>Date:</b> <?php echo date('Y-m-d', strtotime($row['event_time'])); ?> | <b>Time:</b> <?php echo date('h:i A', strtotime($row['event_time'])); ?></p>
                    <p><b>Location:</b> <?php echo htmlspecialchars($row['event_venue']); ?></p>
                    <p><b>Category:</b> <?php echo htmlspecialchars($row['category']); ?></p>
                    <form method="POST" action="join_event.php">
                        <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                        <button type="submit">Join</button>
                    </form>
                </div>
                <?php
                    }
                } else {
                    echo "<p>No available projects at the moment.</p>";
                }
                ?>
            </div>
        </div>

    <div class="enrolled-events">
        <h2>Enrolled Events</h2>
        <div class="event-list">
        <?php
        if ($enrolled_events && $enrolled_events->num_rows > 0) {
            while ($row = $enrolled_events->fetch_assoc()) {
                ?>
                <div class="event-card">
                    <h3><?php echo htmlspecialchars($row['event_name']); ?></h3>
                    <p><b>Organization:</b> <?php echo htmlspecialchars($row['org_name']); ?></p>
                    <p><b>Status:</b> <?php echo htmlspecialchars($row['activity_status']); ?></p>
                    <form method="POST" action="unenroll_event.php">
                        <input type="hidden" name="event_id" value="<?php echo htmlspecialchars($row['event_id']); ?>">
                        <button type="submit">Un-enroll</button>
                    </form>
                </div>
                <?php
            }
        } else {
            echo "<p>You are not enrolled in any projects yet.</p>";
        }
        ?>
        </div>
    </div>
    </section>
    <footer class="site-footer">
  <div class="footer-content">
    <img src="../Landing Page/logo.png" alt="Logo" class="footer-logo">
    <p>&copy; 2025 IWT Project Group 09. All rights reserved.</p>
  </div>
</footer>
</body>
</html>