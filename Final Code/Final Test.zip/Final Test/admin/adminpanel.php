<?php
ini_set('session.cookie_path', '/');
session_start();
include "../db_connection.php";

// Access control
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../Login & Reg/log.php"); // redirect to login if not admin
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../Vol/styless.css">
    <script>
function loadPage(page, btn) {
    // Load into iframe or section
    document.getElementById("contentFrame").src = page;

    // Update active button styling
    let buttons = document.querySelectorAll(".btns button");
    buttons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
}

function logout() {
    window.location.href = "../Login & Reg/logout.php";
}
</script>
</head>
<body>
    <!-- Header section with navigation -->
    <nav class="navbar">
        <div class="logo">
            <a href="#"><img src="../Landing Page/logo.png" alt="Vollie logo"></a>
        </div>
        <div class="btns">
            <button type="button" class="login-btn" onclick="loadPage('dashboard.php', this)">Dashboard</button>
            <button type="button" class="login-btn" onclick="loadPage('show_vol.php', this)">Manage Volunteers</button>
            <button type="button" class="login-btn" onclick="loadPage('show_org.php', this)">Manage Organizations</button>
            <button type="button" class="login-btn" onclick="loadPage('show_events.php', this)">Event Manage</button>
            <button type="button" class="login-btn logout-btn" onclick="logout()">Logout</button>
        </div>
    </nav>

    <section>
        <!-- Use iframe to load pages dynamically -->
        <iframe id="contentFrame" src="dashboard.php" style="width:100%; height:80vh; border:none;"></iframe>
    </section>

    <footer class="site-footer">
        <div class="footer-content">
            <img src="../Landing Page/logo.png" alt="Logo" class="footer-logo">
            <p>&copy; 2025 IWT Project Group 09. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
