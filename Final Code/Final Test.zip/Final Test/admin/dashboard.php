<?php
include "../db_connection.php";

// Count total volunteers
$volQuery = "SELECT COUNT(*) AS total FROM volunteer";
$volResult = mysqli_query($conn, $volQuery);
$volCount = mysqli_fetch_assoc($volResult)['total'] ?? 0;

// Count total organizations
$orgQuery = "SELECT COUNT(*) AS total FROM organization";
$orgResult = mysqli_query($conn, $orgQuery);
$orgCount = mysqli_fetch_assoc($orgResult)['total'] ?? 0;

// Count total events
$eventQuery = "SELECT COUNT(*) AS total FROM event";
$eventResult = mysqli_query($conn, $eventQuery);
$eventCount = mysqli_fetch_assoc($eventResult)['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Functionalities Page</title>
    <link rel="stylesheet" href="../Vol/styless.css">

</head>
<body>
 <div class="stats-container">
    <div class="stat-card">
        <h3>Total Volunteers</h3>
        <p><?php echo $volCount; ?></p>
    </div>

    <div class="stat-card">
        <h3>Total Organizations</h3>
        <p><?php echo $orgCount; ?></p>
    </div>

    <div class="stat-card">
        <h3>Total Events</h3>
        <p><?php echo $eventCount; ?></p>
    </div>
</div>



</body>
</html>