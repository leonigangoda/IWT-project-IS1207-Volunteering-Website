<?php
ini_set('session.cookie_path', '/');
session_start();
include "../db_connection.php";

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "No user selected!";
    exit;
}

$result = $conn->query("SELECT first_name,last_name,nic,email, phone,vol_address,DoB FROM Volunteer WHERE volunteer_id=$id");

if (!$result) {
    die("Query failed: " . $conn->error);
}

$user = $result->fetch_assoc();

// Handle Update
if (isset($_POST['update_user'])) {
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $nic = $_POST['nic'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $vol_address = $_POST['vol_address'];
    $DoB = $_POST['DoB'];
    
    $conn->query("
    UPDATE Volunteer 
    SET 
        first_name='$fname',
        last_name='$lname',
        nic='$nic',
        email='$email',
        phone='$phone',
        vol_address='$vol_address',
        DoB='$DoB'
    WHERE volunteer_id=$id
");

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Volunteer Coordination Platform</title>
   <link rel="stylesheet" type="text/css" href="../Vol/styless.css">
   </head>
<body>
 
    <section class="updt-box">
        <h2>Update</h2>
        <form method="post">
            <input type="text" name="first_name"  value="<?php echo $user['first_name']; ?>" ><br>
            <input type="text" name="last_name"  value="<?php echo $user['last_name']; ?>" ><br>
            <input type="text" name="nic"  value="<?php echo $user['nic']; ?>" ><br>
            <input type="email" name="email" value="<?php echo $user['email']; ?>"><br>
            <input type="text" name="phone" value="<?php echo $user['phone']; ?>"><br>
            <input type="text" name="vol_address"  value="<?php echo $user['vol_address']; ?>"><br>
            <input type="text" name="DoB"  onfocus="this.type='date'" onblur="if(!this.value)this.type='text'" value="<?php echo $user['DoB']; ?>"><br>
            <select id="interest" name="interest">
                    <option value="" disabled selected hidden>-- Field of Interest --</option>
                    <option value="healthcare">Healthcare</option>
                    <option value="arts">Arts</option>
                    <option value="education">Education</option>
                    <option value="environment">Environment</option>
             </select><br>
            
            <button class="updt-btn" type="submit" name="update_user">Update User</button>
            <button class="updt-btn" type="button" onclick="location.href='show_vol.php'">Go Back</button>

        </form>
</section>
</body>
</html>
