<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");

// Ensure organization is logged in
if (!isset($_SESSION['org_id'])) {
    die("Access denied. Please log in as an organization.");
}

$org_id = (int)$_SESSION['org_id'];

// Fetch logged-in organization details
$orgResult = $conn->query("SELECT * FROM Organization WHERE org_id = $org_id");
if (!$orgResult || $orgResult->num_rows === 0) {
    die("Organization not found.");
}

$organization = $orgResult->fetch_assoc();

// Handle form submission for updating profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oname   = $conn->real_escape_string($_POST['oname'] ?? '');
    $reg_no  = $conn->real_escape_string($_POST['reg_no'] ?? '');
    $co_name = $conn->real_escape_string($_POST['co_name'] ?? '');
    $phone   = $conn->real_escape_string($_POST['phone'] ?? '');
    $email   = $conn->real_escape_string($_POST['email'] ?? '');
    $service = $conn->real_escape_string($_POST['interest'] ?? '');
    $pw      = $_POST['pw'] ?? '';
    $cpw     = $_POST['cpw'] ?? '';

    if ($pw !== $cpw) {
        echo "<script>alert('Passwords do not match!');</script>";
    } else {
        $pw_sql = '';
        if (!empty($pw)) {
            $hashed_pw = password_hash($pw, PASSWORD_DEFAULT);
            $pw_sql = ", org_password='$hashed_pw'";
        }

        $update_sql = "
            UPDATE Organization SET
                org_name='$oname',
                org_reg_no='$reg_no',
                contact_person_name='$co_name',
                contact_person_phone='$phone',
                contact_person_email='$email',
                service_type='$service'
                $pw_sql
            WHERE org_id=$org_id
        ";

        if ($conn->query($update_sql) === TRUE) {
            echo "<script>alert('Profile updated successfully');</script>";
            // Refresh organization info
            $orgResult = $conn->query("SELECT * FROM Organization WHERE org_id = $org_id");
            $organization = $orgResult->fetch_assoc();
        } else {
            echo "<script>alert('Profile update failed: " . $conn->error . "');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Organization Profile</title>
    <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <a href="../Landing Page/landingpage.html"><img src="../Landing Page/logo.png" alt="Vollie logo"></a>
    </div>
    <div class="btns">
        <button type="button" class="login-btn" onclick="location.href='myd_org.php'">My Dashboard</button>
        <button type="button" class="login-btn" onclick="location.href='org.php'">Explore Events</button>
        <button type="button" class="login-btn" onclick="location.href='../Login & Reg/logout.php'">Logout</button>
    </div>
</nav>

<section class="dashboard">
    <div class="available-events">
        <div class="profile-pic">
            <img src="r.jpeg" alt="Profile Picture">
        </div>

        <h2>Your Organization Info</h2>
        <table>
            <tbody>
                <tr><th>Organization Name</th><td><?php echo htmlspecialchars($organization['org_name']); ?></td></tr>
                <tr><th>Contact Person</th><td><?php echo htmlspecialchars($organization['contact_person_name']); ?></td></tr>
                <tr><th>Email</th><td><?php echo htmlspecialchars($organization['contact_person_email']); ?></td></tr>
                <tr><th>Phone</th><td><?php echo htmlspecialchars($organization['contact_person_phone']); ?></td></tr>
            </tbody>
        </table>
    </div>

    <section class="profile-dashboard">
        <div class="enrolled-events">
            <?php include "org_stats.php"; ?>
        </div><br>
        <div>
        <div class="enrolled-events">
            <form class="form-section" method="POST" action="">
                <h2>Update Your Profile</h2>

                <label>Organization Name: </label>
                <input type="text" name="oname" value="<?php echo htmlspecialchars($organization['org_name']); ?>" required>

                <label>Organization Registration Number:</label>
                <input type="text" name="reg_no" value="<?php echo htmlspecialchars($organization['org_reg_no']); ?>" required>

                <label>Contact Person's Name: </label>
                <input type="text" name="co_name" value="<?php echo htmlspecialchars($organization['contact_person_name']); ?>" required>

                <label>Contact Person's Phone Number:</label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($organization['contact_person_phone']); ?>" required>

                <label>Email:</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($organization['contact_person_email']); ?>" required>

                <label>Service Type:</label>
                <select name="interest" required>
                    <option value="education" <?php echo ($organization['service_type'] == 'education') ? 'selected' : ''; ?>>Education</option>
                    <option value="environment" <?php echo ($organization['service_type'] == 'environment') ? 'selected' : ''; ?>>Environment</option>
                    <option value="healthcare" <?php echo ($organization['service_type'] == 'healthcare') ? 'selected' : ''; ?>>Healthcare</option>
                    <option value="community_service" <?php echo ($organization['service_type'] == 'community_service') ? 'selected' : ''; ?>>Community Service</option>
                    <option value="disaster_relief" <?php echo ($organization['service_type'] == 'disaster_relief') ? 'selected' : ''; ?>>Disaster Relief</option>
                    <option value="animal_welfare" <?php echo ($organization['service_type'] == 'animal_welfare') ? 'selected' : ''; ?>>Animal Welfare</option>
                    <option value="other" <?php echo ($organization['service_type'] == 'other') ? 'selected' : ''; ?>>Other</option>
                </select><br><br>

                <label>Create New Password:</label>
                <input type="password" name="pw">

                <label>Confirm New Password: </label>
                <input type="password" name="cpw"><br><br>

                <input type="submit" value="UPDATE PROFILE" class="updt-btn">
            </form>
        </div>
        </div>
    </section>
</section>

<footer class="site-footer">
    <div class="footer-content">
        <img src="../Landing Page/logo.png" alt="Logo" class="footer-logo">
        <p>&copy; 2025 IWT Project Group 09. All rights reserved.</p>
    </div>
</footer>
</body>
</html>
