<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $fname = $conn->real_escape_string($_POST['fName']);
    $lname = $conn->real_escape_string($_POST['lName']);
    $nic = $conn->real_escape_string($_POST['nic']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $interest = $conn->real_escape_string($_POST['interest']);
    $password = $_POST['password'];
    $con_password = $_POST['con_password'];

    if ($password != $con_password) {
        echo "Passwords do not match.";
    } else {
        $check_query = "SELECT * FROM Volunteer WHERE email='$email'";
        $result = $conn->query($check_query);

        if ($result->num_rows > 0) {
            echo "Account already exists.";
        } else {
            $hashed_pw = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO Volunteer(first_name,last_name,nic,phone,email,vol_address,DoB,interest,password)
                             VALUES ('$fname','$lname','$nic','$phone','$email','$address','$dob','$interest','$hashed_pw')";

            if ($conn->query($insert_query) === TRUE) {
                echo "Registration successful!";
            } else {
                echo "Error: " . $conn->error;
            }
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Volunteer Managemant Platform</title>
        <link rel="stylesheet" href="reg_style.css">
    </head>
 
    <body>
        <div class="container">
            <div class="form-box login" >
                <form action="" method="post">
                    <h1>Registration</h1>
                    <div class="input-box">
                        <input type="text" name="fName" placeholder="First Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="lName" placeholder="Last Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="nic" placeholder="NIC Number" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="phone" placeholder="Phone Number" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="email" placeholder="Email" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="address" placeholder="Address" required>
                    </div>
                    <div class="input-box">
                    <input type="text" name="dob" placeholder="Date of Birth" onfocus="this.type='date'" onblur="if(!this.value)this.type='text'">
                    </div>
                    <div class="input-box">
                        <select id="interest" name="interest">
                            <option value="" disabled selected hidden>-- Field of Interest --</option>
                            <option value="Education">Education</option>
                            <option value="Environment">Environment</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Community Service">Community Service</option>
                            <option value="Disaster Relief">Disaster Relief</option>
                            <option value="Animal Welfare">Animal Welfare</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <input type="password" name="password" placeholder="Password" required>
                    </div>
                    <div class="input-box">
                        <input type="password" name="con_password" placeholder="Confirm Paasword" required>
                    </div>
                    <button type="submit" name="submit" class="btn">Register</button>

                </form>
            </div>
            <div class="toggle-box">
                <div class="toggle-panel toggle-left">
                    <div class="welcome-msg">
                        <div class="banner">
                            <h1>Welcome Back!</h1>
                            <p>To keep connected with us please log in with your info.</p>
                        </div>
                    </div>
                    <div class="btn-group">
                    <button class="btn register-btn" onclick="location.href='log.php'">Log in</a></button>
                    </div>
                </div>
                

            </div>
        </div>
    </body>
</html>