<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");

$error_message ="";
$success_message="";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ---- Registration ----
    if (isset($_POST['submit'])) {
        $orgname = $_POST['orgname'];
        $orgreg = $_POST['orgreg'];
        $cpname = $_POST['cpname'];
        $cpphone = $_POST['cpphone'];
        $cpemail = $_POST['cpemail'];
        $service_type = $_POST['service_type'];
        $orgpw = $_POST['orgpw'];
        $orgconpw = $_POST['orgconpw'];
        
        if (!filter_var($cpemail, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Invalid email format";
        }
        elseif ($orgpw != $orgconpw) {
            $error_message = "Passwords do not match.";
        } else {
            // Check if org reg number already exists
            $check_query = "SELECT * FROM organization WHERE org_reg_no='$orgreg'";
            $result = $conn->query($check_query);
            
            if ($result->num_rows > 0) {
                $error_message = "Account already exists.";
            } else {
                // HASH THE PASSWORD before saving
                $hashed_pw = password_hash($orgpw, PASSWORD_DEFAULT);

                // Insert new record
                $insert_query = "INSERT INTO organization(org_reg_no, org_name, contact_person_name, contact_person_email, contact_person_phone, service_type, org_password) 
                                 VALUES ('$orgreg','$orgname','$cpname','$cpemail','$cpphone','$service_type','$hashed_pw')";
                
                if ($conn->query($insert_query) === TRUE) {
                    $success_message= "Registration successful!";
                } else {
                    echo "Error: " . $conn->error;
                }
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Volunteer Managemant Platform</title>
        <link rel="stylesheet" href="reg_style.css">
        
    </head>
 
    <body>
        <div class="container">
            <div class="form-box login">
                <form action="" method="post">
                    <h1>Registration</h1>
                    <?php if ($error_message != ""): ?>
                    <div style="color: red; margin-bottom: 20px; padding: 10px; background: #f8d7da; border-radius: 5px;">
                        <?php echo $error_message; ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($success_message != ""): ?>
                    <div style="color: #fff; margin-bottom: 20px; padding: 10px; background: green; border-radius: 5px;">
                        <?php echo $success_message; ?>
                    </div>
                    <?php endif; ?>
                    <div class="input-box">
                        <input type="text" name="orgname" placeholder="Organization Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="orgreg" placeholder="Organization Registeration Number" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="cpname" placeholder="Contact Person's Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="cpphone" placeholder="Contact Person's Phone Number" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="cpemail" placeholder="Contact Person's Email" required>
                    </div>
                    <div class="input-box">
                        <select id="service" name="service_type">
                            <option value="" disabled selected hidden>-- Service Type --</option>
                            <option value="Education">Education</option>
                            <option value="Environment">Environment</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Community Service">Community Service</option>
                            <option value="Disaster Relief">Disaster Relief</option>
                            <option value="Animal Welfare">Animal Welfare</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <input type="password" name="orgpw" placeholder="Password" required>
                    </div>
                    <div class="input-box">
                        <input type="password" name="orgconpw" placeholder="Confirm Paasword" required>
                    </div>
                    <button type="submit" name="submit" class="btn">Register</button>

                </form>
            </div>
            <div class="toggle-box">
                <div class="toggle-panel toggle-left">
                    <div class="welcome-msg">
                        <div class="banner">
                        <h1>connect.</h1><h1>volunteer.</h1><h1>transform.</h1>
                        <p>Connect organizations needing help with<br>volunteers ready to contribute.</p>
                    </div>
                    </div>
                    <div class="btn-group">
                    <button class="btn register-btn" onclick="location.href='log.php'" style="width: 315px;">Log in</a></button>
                    </div>
                </div>
                

            </div>
        </div>
    </body>
</html>