<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");

$error_message ="";
$success_message="";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $fname = $conn->real_escape_string($_POST['fName']);
    $lname = $conn->real_escape_string($_POST['lName']);
    $nic = $conn->real_escape_string($_POST['nic']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $interest = $conn->real_escape_string($_POST['interest']);
    $password = $_POST['password'];
    $con_password = $_POST['con_password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Invalid email format";
    }
    elseif ($password != $con_password) {
        $error_message = "Passwords do not match.";
    } else {
        $check_query = "SELECT * FROM Volunteer WHERE email='$email'";
        $result = $conn->query($check_query);

        if ($result->num_rows > 0) {
            $error_message = "Account already exists.";
        } else {
            $hashed_pw = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO Volunteer(first_name,last_name,nic,phone,email,vol_address,DoB,interest,password)
                             VALUES ('$fname','$lname','$nic','$phone','$email','$address','$dob','$interest','$hashed_pw')";

            if ($conn->query($insert_query) === TRUE) {
                 $success_message ="Registration successful!";
            } else {
                echo "Error: " . $conn->error;
            }
        }
    }
}

?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Volunteer Managemant Platform</title>
        <link rel="stylesheet" href="reg_style.css">
    </head>
 
    <body>
        <div class="container">
            <div class="form-box login" >
                <form action="" method="post" name="form1">
                    <h1>Registration</h1>
                    <?php if ($error_message != ""): ?>
                    <div style="color: red; margin-bottom: 20px; padding: 10px; background: #f8d7da; border-radius: 5px;">
                        <?php echo $error_message; ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($success_message != ""): ?>
                    <div style="color: #fff; margin-bottom: 20px; padding: 10px; background: green; border-radius: 5px;">
                        <?php echo $success_message; ?>
                    </div>
                    <?php endif; ?>
                    <div class="input-box">
                        <input type="text" name="fName" placeholder="First Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="lName" placeholder="Last Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="nic" placeholder="NIC Number" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="phone" placeholder="Phone Number" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="email" placeholder="Email" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="address" placeholder="Address" required>
                    </div>
                    <div class="input-box">
                    <input type="text" name="dob" placeholder="Date of Birth" onfocus="this.type='date'" onblur="if(!this.value)this.type='text'">
                    </div>
                    <div class="input-box">
                        <select id="interest" name="interest">
                            <option value="" disabled selected hidden>-- Field of Interest --</option>
                            <option value="Education">Education</option>
                            <option value="Environment">Environment</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Community Service">Community Service</option>
                            <option value="Disaster Relief">Disaster Relief</option>
                            <option value="Animal Welfare">Animal Welfare</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <input type="password" name="password" placeholder="Password" required>
                    </div>
                    <div class="input-box">
                        <input type="password" name="con_password" placeholder="Confirm Paasword" required>
                    </div>
                    <button type="submit" name="submit" class="btn">Register</button>

                </form>
            </div>
            <div class="toggle-box">
                <div class="toggle-panel toggle-left">
                    <div class="welcome-msg">
                        <div class="banner">
                        <h1>connect.</h1><h1>volunteer.</h1><h1>transform.</h1>
                        <p>Connect organizations needing help with<br>volunteers ready to contribute.</p>
                    </div>
                    </div>
                    <div class="btn-group">
                    <button class="btn register-btn" onclick="location.href='log.php'" style="width: 315px;">Log in</a></button>
                    </div>
                </div>
                

            </div>
        </div>
    </body>
</html>