<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");

// Ensure volunteer is logged in
if (!isset($_SESSION['volunteer_id'])) {
    die("Access denied. Please log in first.");
}

$user_id = (int)$_SESSION['volunteer_id'];

// Fetch logged-in volunteer
$result = $conn->query("SELECT * FROM Volunteer WHERE volunteer_id = $user_id");
if (!$result) {
    die("Error fetching volunteer: " . $conn->error);
}

$volunteer = $result->fetch_assoc();
if (!$volunteer) {
    die("No volunteer found for ID $user_id");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname    = $conn->real_escape_string($_POST['first_name'] ?? '');
    $lname    = $conn->real_escape_string($_POST['last_name'] ?? '');
    $nic      = $conn->real_escape_string($_POST['nic'] ?? '');
    $email    = $conn->real_escape_string($_POST['email'] ?? '');
    $address  = $conn->real_escape_string($_POST['vol_address'] ?? '');
    $phone    = $conn->real_escape_string($_POST['phone'] ?? '');
    $DoB      = $conn->real_escape_string($_POST['DoB'] ?? '');
    $interest = $conn->real_escape_string($_POST['interest'] ?? '');
    $pw       = $_POST['password'] ?? '';
    $cpw      = $_POST['cpw'] ?? '';

    if ($pw !== $cpw) {
        echo "<script>alert('Passwords do not match!');</script>";
    } else {
        // Hash password if provided
        $pw_sql = '';
        if (!empty($pw)) {
            $hashed_pw = password_hash($pw, PASSWORD_DEFAULT);
            $pw_sql = ", password='$hashed_pw'";
        }

        $update_sql = "
            UPDATE Volunteer SET
                first_name='$fname',
                last_name='$lname',
                nic='$nic',
                phone='$phone',
                email='$email',
                vol_address='$address',
                interest='$interest',
                DoB='$DoB'
                $pw_sql
            WHERE volunteer_id=$user_id
        ";

        if ($conn->query($update_sql) === TRUE) {
            echo "<script>alert('Profile updated successfully');</script>";
            // Refresh volunteer info
            $result = $conn->query("SELECT * FROM Volunteer WHERE volunteer_id = $user_id");
            $volunteer = $result->fetch_assoc();
        } else {
            echo "<script>alert('Profile update failed: " . $conn->error . "');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Functionalities Page</title>
    <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <a href="../Landing Page/landingpage.html"><img src="../Landing Page/logo.png" alt="Vollie logo"></a>
    </div>
    <div class="btns">
        <button type="button" class="login-btn" onclick="location.href='myd_vol.php'"><b>My Dashboard</button>
        <button type="button" class="login-btn" onclick="location.href='functionalities.php'"><b>Explore Events</b></button>
        <button type="button" class="login-btn" onclick="location.href='../Login & Reg/logout.php'">Logout</b></button>
    </div>
</nav>

<section class="dashboard">
    <div class="available-events">
        <div class="profile-pic">
            <img src="r.jpeg" alt="Profile Picture">
        </div>

        <h2>Your Info</h2>
        <table>
            <tbody>
                <tr><th>Volunteer ID</th><td><?php echo $volunteer['volunteer_id']; ?></td></tr>
                <tr><th>First Name</th><td><?php echo htmlspecialchars($volunteer['first_name']); ?></td></tr>
                <tr><th>Last Name</th><td><?php echo htmlspecialchars($volunteer['last_name']); ?></td></tr>
                <tr><th>Email</th><td><?php echo htmlspecialchars($volunteer['email']); ?></td></tr>
                <tr><th>Phone</th><td><?php echo htmlspecialchars($volunteer['phone']); ?></td></tr>
            </tbody>
        </table>
    </div>

    <section class="profile-dashboard">
        <div class="enrolled-events">
            <?php include "vol_stats.php" ?>
        </div><br>
        <diV>
        <div class="enrolled-events">
            <form class="form-section" method="POST" action="">
                <h2>Update Your Profile</h2>

                <label>First Name: </label>
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($volunteer['first_name']); ?>">

                <label>Last Name: </label>
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($volunteer['last_name']); ?>">

                <label>NIC :</label>
                <input type="text" name="nic" value="<?php echo htmlspecialchars($volunteer['nic']); ?>">

                <label>Email :</label>
                <input type="text" name="email" value="<?php echo htmlspecialchars($volunteer['email']); ?>">

                <label>Address :</label>
                <input type="text" name="vol_address" value="<?php echo htmlspecialchars($volunteer['vol_address']); ?>">

                <label>Date Of Birth :</label>
                <input type="date" name="DoB" value="<?php echo $volunteer['DoB']; ?>">

                <label>Phone Number :</label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($volunteer['phone']); ?>">

                <label>Interest :</label>
                <select name="interest">
                    <option value="education" <?php echo ($volunteer['interest'] == 'education') ? 'selected' : ''; ?>>Education</option>
                    <option value="environment" <?php echo ($volunteer['interest'] == 'environment') ? 'selected' : ''; ?>>Environment</option>
                    <option value="healthcare" <?php echo ($volunteer['interest'] == 'healthcare') ? 'selected' : ''; ?>>Healthcare</option>
                    <option value="community_service" <?php echo ($volunteer['interest'] == 'community_service') ? 'selected' : ''; ?>>Community Service</option>
                    <option value="disaster_relief" <?php echo ($volunteer['interest'] == 'disaster_relief') ? 'selected' : ''; ?>>Disaster Relief</option>
                    <option value="animal_welfare" <?php echo ($volunteer['interest'] == 'animal_welfare') ? 'selected' : ''; ?>>Animal Welfare</option>
                    <option value="other" <?php echo ($volunteer['interest'] == 'other') ? 'selected' : ''; ?>>Other</option>
                </select><br><br>

                <label>Create New Password :</label>
                <input type="password" name="password">

                <label>Confirm New Password: </label>
                <input type="password" name="cpw">

                <input type="submit" value="UPDATE PROFILE" class="updt-btn">
            </form>
        </div>
        </div>
    </section>
</section>

<footer class="site-footer">
    <div class="footer-content">
        <img src="../Landing Page/logo.png" alt="Logo" class="footer-logo">
        <p>&copy; 2025 IWT Project Group 09. All rights reserved.</p>
    </div>
</footer>
</body>
</html>
