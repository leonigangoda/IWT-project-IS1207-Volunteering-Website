<?php
include("db_connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) {
        $admin_name = $_POST['admin_name'];
        $admin_email = $_POST['admin_email'];
        $admin_password = $_POST['admin_password'];
        $admin_conpassword = $_POST['admin_conpassword'];
        
        if ($admin_password != $admin_conpassword ) {
            echo ("Passwords do not match.");
        } // HASH THE PASSWORD before saving
                $hashed_pw = password_hash($admin_password, PASSWORD_DEFAULT);

                // Insert new record
                $insert_query = "INSERT INTO admin(admin_name, admin_password,admin_email) 
                                 VALUES ('$admin_name','$hashed_pw','$admin_email')";
                
                if ($conn->query($insert_query) === TRUE) {
                    echo ("Registration successful!");
                } else {
                    echo "Error: " . $conn->error;
                }
            }
        }
?>

<form method="POST">
    <input type="text" name="admin_name" placeholder="Name" required><br><br>
    <input type="text" name="admin_email" placeholder="Email" required><br><br>
    <input type="password" name="admin_password" placeholder="Password" required><br><br>
    <input type="password" name="admin_conpassword" placeholder="Confirm Password" required>
    <button type="submit" name="submit">Register</button>
</form>
