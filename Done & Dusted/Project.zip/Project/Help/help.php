<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Organization Profile</title>
    <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <a href="../Landing Page/landingpage.html"><img src="../Landing Page/logo.png" alt="Vollie logo"></a>
    </div>
    <div class="btns">
        <button type="button" class="login-btn" onclick="location.href='../Landing Page/landingpage.html'"><b>Home</button>
        <button type="button" class="login-btn" onclick="location.href='../Login & Reg/log.php'">Login</b></button>
    </div>
</nav>



<footer class="site-footer">
    <div class="footer-content">
        <img src="../Landing Page/logo.png" alt="Logo" class="footer-logo">
        <p>&copy; 2025 IWT Project Group 09. All rights reserved.</p>
    </div>
</footer>
</body>
</html>
