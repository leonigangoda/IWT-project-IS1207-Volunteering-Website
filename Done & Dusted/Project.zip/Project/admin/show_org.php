<?php
include "../db_connection.php";

// Show Org
$organization = mysqli_query($conn, "
    SELECT org_id,org_reg_no,org_name,contact_person_name,contact_person_email,contact_person_phone
    FROM organization
");

// Delete 
if (isset($_GET['delete_id'])) {
    $org_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM organization WHERE org_id = '$org_id'";
    mysqli_query($conn, $deleteQuery);
    header("Location: show_org.php"); // refresh page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users</title>
 <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>
  <div class="stats-container">
<table>
    <thead>
      <tr>
        <th>Organization Name</th>
        <th>Reg Number</th>
        <th>Contact Person</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($organization)) { ?>
      <tr>
        <td><?php echo $row['org_name']; ?></td>
        <td><?php echo $row['org_reg_no']; ?></td>
        <td><?php echo $row['contact_person_name']; ?></td>
        <td><?php echo $row['contact_person_email']; ?></td>
        <td><?php echo $row['contact_person_phone']; ?></td>
        <td>
        <a class="delete-btn" href="show_org.php?delete_id=<?php echo $row['org_id']; ?>" 
           onclick="return confirm('Are you sure you want to delete this event?')">Delete</a>
        <button class="updt-btn" onclick="location.href='update_org.php?id=<?php echo $row['org_id']; ?>'">Update</button>
        </td>
      </tr>
    </tbody>
<?php } ?>
</table>
      </div>
</body>
</html>