<?php
include "../db_connection.php";

// Show Org
$events = mysqli_query($conn, "
    SELECT e.event_id, e.event_name, e.event_time, e.event_venue, e.description, o.org_name
    FROM Event e
    JOIN Organization o ON e.org_id = o.org_id
");


// Delete 
if (isset($_GET['delete_id'])) {
    $event_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM event WHERE event_id = '$event_id'";
    mysqli_query($conn, $deleteQuery);
    header("Location: show_events.php"); // refresh page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users</title>
 <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>
  <div class="stats-container">
<table>
    <thead>
      <tr>
        <th>Event Name</th>
        <th>Organization Name</th>
        <th>Event Time</th>
        <th>Event Venue</th>
        <th>description</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($events)) { ?>
      <tr>
        <td><?php echo $row['event_name']; ?></td>
        <td><?php echo $row['org_name']; ?></td>
        <td><?php echo $row['event_time']; ?></td>
        <td><?php echo $row['event_venue']; ?></td>
        <td><?php echo $row['description']; ?></td>
        <td>
        <a class="delete-btn" href="show_events.php?delete_id=<?php echo $row['event_id']; ?>" 
           onclick="return confirm('Are you sure you want to delete this event?')">Delete</a>
        <button class="updt-btn" onclick="location.href='Eventmanage.php?id=<?php echo $row['event_id']; ?>'">Update</button>
        </td>
      </tr>
    </tbody>
<?php } ?>
</table>
      </div>
</body>
</html>