<?php
ini_set('session.cookie_path', '/');
session_start();
include "../db_connection.php";

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "No user selected!";
    exit;
}

$result = $conn->query("SELECT event_name,event_time,event_venue,description FROM event WHERE event_id=$id");

if (!$result) {
    die("Query failed: " . $conn->error);
}

$event = $result->fetch_assoc();


// Handle Update
if (isset($_POST['update_user'])) {

    $event_name = $_POST['event_name'];
    $event_time = $_POST['event_time'];
    $event_venue = $_POST['event_venue'];
    $description=$_POST['description'];


    $conn->query("
    UPDATE event 
    SET 
        event_name='$event_name',
        event_time='$event_time',
        event_venue='$event_venue',
        description='$description'
    WHERE event_id=$id
    ");

    echo "Event updated successfully!";
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Volunteer Coordination Platform</title>
   <link rel="stylesheet" type="text/css" href="../Vol/styless.css">
   </head>
<body>
 
    <div class="updt-box">
        <h2>Update</h2>
        <form method="post">
            <input type="text" name="event_name"  value="<?php echo $event['event_name']; ?>" ><br>
            <input type="time" name="event_time"  value="<?php echo $event['event_time']; ?>" ><br>
            <input type="text" name="event_venue" value="<?php echo $event['event_venue']; ?>"><br>
            <input type="text" name="description" value="<?php echo $event['description']; ?>"><br>
            
            <button class="updt-btn" type="submit" name="update_user">Update Event</button>
            <button class="updt-btn" type="button" onclick="location.href='show_vol.php'">Go Back</button>
        </form>
    </div>
</body>
</html>
