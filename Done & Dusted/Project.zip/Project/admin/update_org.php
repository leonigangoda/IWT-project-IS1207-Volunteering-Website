<?php
ini_set('session.cookie_path', '/');
session_start();
include "../db_connection.php";

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "No user selected!";
    exit;
}

$result = $conn->query("SELECT contact_person_name,contact_person_email,contact_person_phone FROM organization WHERE org_id=$id");

if (!$result) {
    die("Query failed: " . $conn->error);
}

$user = $result->fetch_assoc();


// Handle Update
if (isset($_POST['update_user'])) {

    $contact_person_name = $_POST['contact_person_name'];
    $contact_person_email = $_POST['contact_person_email'];
    $contact_person_phone = $_POST['contact_person_phone'];


    $conn->query("
    UPDATE organization 
    SET 
        contact_person_name='$contact_person_name',
        contact_person_email='$contact_person_email',
        contact_person_phone='$contact_person_phone'
    WHERE org_id=$id
    ");

    echo "Organization updated successfully!";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Volunteer Coordination Platform</title>
   <link rel="stylesheet" type="text/css" href="../Vol/styless.css">
   </head>
<body>
 
    <div class="updt-box">
        <h2>Update</h2>
        <form method="post">
            <input type="text" name="contact_person_name"  value="<?php echo $user['contact_person_name']; ?>" ><br>
            <input type="text" name="contact_person_email"  value="<?php echo $user['contact_person_email']; ?>" ><br>
            <input type="text" name="contact_person_phone" value="<?php echo $user['contact_person_phone']; ?>"><br>
            
            <button class="updt-btn" type="submit" name="update_user">Update Organization</button>
            <button class="updt-btn" type="button" onclick="location.href='show_vol.php'">Go Back</button>
        </form>
    </div>
</body>
</html>
