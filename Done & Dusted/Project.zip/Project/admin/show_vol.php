<?php
include "../db_connection.php";

// Show Voulnteer
$volunteers = mysqli_query($conn, "
    SELECT volunteer_id,first_name,last_name,nic,phone,email,vol_address,DoB,interest
    FROM volunteer
");
// Delete 
if (isset($_GET['delete_id'])) {
    $volunteer_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM volunteer WHERE volunteer_id = '$volunteer_id'";
    mysqli_query($conn, $deleteQuery);
    header("Location: show_vol.php"); // refresh page
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users</title>
 <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>
 <div class="stats-container">
<table>
    <thead>
      <tr>
        <th>Volunteer ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Phone</th>      
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($volunteers)){  ?>
      <tr>
        <td><?php echo $row['volunteer_id']; ?></td>
        <td><?php echo $row['first_name']; ?></td>
        <td><?php echo $row['last_name']; ?></td>
       <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['phone']; ?></td>
        <td>
           <a class="delete-btn" href="show_vol.php?delete_id=<?php echo $row['volunteer_id']; ?>" 
           onclick="return confirm('Are you sure you want to delete this event?')">Delete</a>
           <button class="updt-btn" onclick="location.href='update_vol.php?id=<?php echo $row['volunteer_id']; ?>'">Update</button>
        </td>
        </td>
      </tr>
    </tbody>
<?php } ?>
</table>
      </div>
</body>
</html>