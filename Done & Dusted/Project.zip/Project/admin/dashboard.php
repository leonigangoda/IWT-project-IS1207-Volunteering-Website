<?php
include "../db_connection.php";

// ---- Define 3 months cutoff ----
$cutoffDate = date('Y-m-d H:i:s', strtotime('-3 months'));

// ---- Count active volunteers ----
$volQuery = "
    SELECT COUNT(*) AS total
    FROM Volunteer v
    LEFT JOIN user_login ul ON v.volunteer_id = ul.volunteer_id
    WHERE ul.last_login IS NOT NULL AND ul.last_login >= '$cutoffDate'
";
$volResult = mysqli_query($conn, $volQuery);
$volCount = mysqli_fetch_assoc($volResult)['total'] ?? 0;

// ---- Count active organizations ----
$orgQuery = "
    SELECT COUNT(*) AS total
    FROM Organization o
    LEFT JOIN user_login ul ON o.org_id = ul.org_id
    WHERE ul.last_login IS NOT NULL AND ul.last_login >= '$cutoffDate'
";
$orgResult = mysqli_query($conn, $orgQuery);
$orgCount = mysqli_fetch_assoc($orgResult)['total'] ?? 0;

// ---- Count total events ----
$eventQuery = "SELECT COUNT(*) AS total FROM Event";
$eventResult = mysqli_query($conn, $eventQuery);
$eventCount = mysqli_fetch_assoc($eventResult)['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Functionalities Page</title>
    <link rel="stylesheet" href="../Vol/styless.css">
    <style>
        .stats-container { display: flex; gap: 20px; padding: 20px; }
        .stat-card { background: #f2f2f2; padding: 20px; border-radius: 8px; text-align: center; flex: 1; }
        .stat-card h3 { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="stats-container">
        <div class="stat-card">
            <h3>Total Active Volunteers (last 3 months)</h3>
            <p><?php echo $volCount; ?></p>
        </div>

        <div class="stat-card">
            <h3>Total Active Organizations (last 3 months)</h3>
            <p><?php echo $orgCount; ?></p>
        </div>

        <div class="stat-card">
            <h3>Total Events</h3>
            <p><?php echo $eventCount; ?></p>
        </div>
    </div>
</body>
</html>
