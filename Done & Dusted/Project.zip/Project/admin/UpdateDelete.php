<?php
ini_set('session.cookie_path', '/');
session_start();
include "../db_connection.php";

// Handle Delete
if (isset($_POST['delete_user'])) {
    $type = $_POST['user_type'];
    $id = intval($_POST['user_id']);
    if ($type === "volunteer") {
        $conn->query("DELETE FROM Volunteer WHERE volunteer_id = $id");
    } elseif ($type === "organization") {
        $conn->query("DELETE FROM Organization WHERE org_id = $id");
    }
}

// Handle Update
if (isset($_POST['update_user'])) {
    $type = $_POST['user_type'];
    $id = intval($_POST['user_id']);
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    if ($type === "volunteer") {
        $conn->query("UPDATE Volunteer SET email='$email', phone='$phone' WHERE volunteer_id=$id");
    } elseif ($type === "organization") {
        $conn->query("UPDATE Organization SET contact_person_email='$email', contact_person_phone='$phone' WHERE org_id=$id");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Volunteer Coordination Platform</title>
   <link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
<!-- Update/Delete Section -->
    <div class="card">
        <h2>Update/Delete User</h2>
        <form method="post">
            <select name="user_type">
                <option value="volunteer">Volunteer</option>
                <option value="organization">Organization</option>
            </select><br>
            <input type="number" name="user_id" placeholder="User ID" required><br>
            <input type="email" name="email" placeholder="New Email"><br>
            <input type="text" name="phone" placeholder="New Phone"><br>
            <button type="submit" name="update_user">Update User</button>
            <button type="submit" name="delete_user">Delete User</button>
        </form>
    </div>


</body>
</html>
