<?php
header("Location:Landing Page/landingpage.html");
exit();
?>