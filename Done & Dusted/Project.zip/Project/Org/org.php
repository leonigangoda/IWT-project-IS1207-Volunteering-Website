<?php
ini_set('session.cookie_path', '/');
session_start();
include("../db_connection.php");

// Check if org is logged in
if (!isset($_SESSION['org_id'])) {
    header("Location: ../Login & Reg/log.php");
    exit();
}

$org_id = $_SESSION['org_id'];

// Fetch all events for this organization
$event_sql = "SELECT * FROM Event WHERE org_id = '$org_id' ORDER BY created_date DESC";
$result = mysqli_query($conn, $event_sql);

if (!$result) {
    die("Error fetching events: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Organization Dashboard</title>
    <link rel="stylesheet" href="../Vol/styless.css">
</head>
<body>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="logo">
            <a href="../Landing Page/landingpage.html">
                <img src="../Landing Page/logo.png" alt="Vollie logo">
            </a>
        </div>
        <div class="btns">
            <button type="button" class="login-btn" onclick="location.href='myd_org.php'"><b>My Dashboard</button>
            <button type="button" class="login-btn" onclick="location.href='#'"><b>My Events</b></button>
            <button type="button" class="login-btn" onclick="location.href='../Login & Reg/logout.php'">Logout</b></button>
        </div>
    </nav>

    <section class="dashboard">
        <!-- Create Event Panel -->
        <div class="available-events">
            <h2>Create Events</h2>
            <div class="event-list">
                <div class="projects-grid">
                    <div class="project-card" style="border:2px dashed #007bff; color:#007bff; cursor:pointer;" onclick="openCreateEvent()">
                        <h3>+ Create New Event</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- My Events Panel -->
        <div class="enrolled-events">
            <h2>My Events</h2>
            <div class="event-list">
                <?php if (mysqli_num_rows($result) > 0) { ?>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <div class="event-card">
                            <h3><?php echo htmlspecialchars($row['event_name']); ?></h3>
                            <p><b>Date:</b> <?php echo date('Y-m-d', strtotime($row['event_time'])); ?> | <b>Time:</b> <?php echo date('h:i A', strtotime($row['event_time'])); ?></p>
                            <p><strong>Venue:</strong> <?php echo htmlspecialchars($row['event_venue']); ?></p>
                            <p><strong>Category:</strong> <?php echo htmlspecialchars($row['category']); ?></p>
                            <p><strong>Description:</strong> <?php echo htmlspecialchars($row['description']); ?></p>

                            <button class="btn-all btn-warning"
                                onclick="openEditEvent(
                                    '<?php echo $row['event_id']; ?>',
                                    '<?php echo htmlspecialchars($row['event_name']); ?>',
                                    '<?php echo date('Y-m-d\TH:i', strtotime($row['event_time'])); ?>',
                                    '<?php echo htmlspecialchars($row['event_venue']); ?>',
                                    '<?php echo htmlspecialchars($row['category']); ?>',
                                    '<?php echo htmlspecialchars($row['description']); ?>'
                                )">Edit</button>

                            <a href="org_delete_event.php?id=<?php echo $row['event_id']; ?>" 
                               class="btn-all btn-danger" 
                               onclick="return confirm('Delete this event?')">Delete</a>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <p>No events created yet.</p>
                <?php } ?>
            </div>
        </div>
    </section>

    <!-- Create Event Modal -->
    <div id="createEvent" class="event-all">
        <div class="event-content">
            <span class="close" onclick="closeCreateEvent()">&times;</span>
            <h2>Create a New Event</h2>
            <form id="createForm" action="org_create_event.php" method="POST">
                <label>Event Name*</label>
                <input type="text" name="eventName" required>

                <label>Date & Time*</label>
                <input type="datetime-local" name="eventTime" required>

                <label>Venue*</label>
                <input type="text" name="eventVenue" required>

                <label>Category</label>
                <select name="category">
                    <option value="">Select Category</option>
                    <option value="Education">Education</option>
                    <option value="Environment">Environment</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Community Service">Community Service</option>
                    <option value="Disaster Relief">Disaster Relief</option>
                    <option value="Animal Welfare">Animal Welfare</option>
                    <option value="Other">Other</option>
                </select>

                <label>Description</label>
                <textarea name="description" maxlength="255"></textarea>

                <button type="submit" class="btn-all btn-primary">Create</button>
            </form>
        </div>
    </div>

    <!-- Edit Event Modal -->
    <div id="editEvent" class="event-all">
        <div class="event-content">
            <span class="close" onclick="closeEditEvent()">&times;</span>
            <h2>Edit your Event</h2>
            <form id="editForm" action="org_edit_event.php" method="POST">
                <input type="hidden" name="event_id" id="edit_event_id">

                <label>Event Name*</label>
                <input type="text" name="eventName" id="edit_eventName" required>

                <label>Date & Time*</label>
                <input type="datetime-local" name="eventTime" id="edit_eventTime" required>

                <label>Venue*</label>
                <input type="text" name="eventVenue" id="edit_eventVenue" required>

                <label>Category</label>
                <select name="category" id="edit_category">
                    <option value="">Select Category</option>
                    <option value="Education">Education</option>
                    <option value="Environment">Environment</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Community Service">Community Service</option>
                    <option value="Disaster Relief">Disaster Relief</option>
                    <option value="Animal Welfare">Animal Welfare</option>
                    <option value="Other">Other</option>
                </select>

                <label>Description</label>
                <textarea name="description" id="edit_description" maxlength="255"></textarea>

                <button type="submit" class="btn-all btn-primary">Update</button>
            </form>
        </div>
    </div>

    <!-- JS -->
    <script>
        // Create Event form
        function openCreateEvent() {
            document.getElementById("createEvent").style.display = "block";
        }
        function closeCreateEvent() {
            document.getElementById("createEvent").style.display = "none";
        }

        // Edit Event Form
        function openEditEvent(id, name, time, venue, category, desc) {
            document.getElementById("edit_event_id").value = id;
            document.getElementById("edit_eventName").value = name;
            document.getElementById("edit_eventTime").value = time;
            document.getElementById("edit_eventVenue").value = venue;
            document.getElementById("edit_category").value = category;
            document.getElementById("edit_description").value = desc;
            document.getElementById("editEvent").style.display = "block";
        }
        function closeEditEvent() {
            document.getElementById("editEvent").style.display = "none";
        }

        // Close forms when clicking outside
        window.onclick = function(event) {
            const createEvent = document.getElementById("createEvent");
            const editEvent = document.getElementById("editEvent");
            if (event.target === createEvent) { createEvent.style.display = "none"; }
            if (event.target === editEvent) { editEvent.style.display = "none"; }
        }
    </script>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="footer-content">
            <img src="../Landing Page/logo.png" alt="Logo" class="footer-logo">
            <p>&copy; 2025 IWT Project Group 09. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
