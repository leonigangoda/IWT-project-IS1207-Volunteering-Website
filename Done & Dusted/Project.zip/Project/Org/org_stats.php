<?php
if (!isset($_SESSION['org_id'])) {
    die("Access denied!");
}

$org_id = (int)$_SESSION['org_id'];

// Total events posted by this organization
$eventsQuery = "SELECT COUNT(*) AS total_events FROM Event WHERE org_id = $org_id";
$eventsResult = $conn->query($eventsQuery);
$totalEvents = $eventsResult->fetch_assoc()['total_events'] ?? 0;

// Total volunteers that joined at least one event of this organization
$volunteersQuery = "
    SELECT COUNT(DISTINCT volunteer_id) AS total_volunteers
    FROM event_assignment
    WHERE org_id = $org_id
";
$volunteersResult = $conn->query($volunteersQuery);
$totalVolunteers = $volunteersResult->fetch_assoc()['total_volunteers'] ?? 0;
?>

<div class="stats-container">
    <div class="stat-card">
        <div class="stat-label">Total Events Posted</div>
        <div class="stat-number"><?php echo $totalEvents; ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-label">Volunteers Joined</div>
        <div class="stat-number"><?php echo $totalVolunteers; ?></div>
    </div>
</div>
